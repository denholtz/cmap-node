module.exports = {
    secret: process.env.JWT_SECRET
}