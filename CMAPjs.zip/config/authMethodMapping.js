module.exports = {
    local: 1,
    jwt: 2,
    apiKey: 3
}