module.exports = {
    storedProcedureArgumentMissing: 'Stored procedure call was missing one or more of: spName, tableName, fields, dt1, dt2, lat1, lat2, lon1, lon2, depth1, depth2.',
    customQueryMissing: 'No query was found in the request body.',
}