self.__precacheManifest = [
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "28275859362bc8bacb1c",
    "url": "/static/js/main.a62827b8.chunk.js"
  },
  {
    "revision": "2a9633999f9aa3fa3e22",
    "url": "/static/js/2.80845d5b.chunk.js"
  },
  {
    "revision": "28275859362bc8bacb1c",
    "url": "/static/css/main.b74a1e3f.chunk.css"
  },
  {
    "revision": "2a9633999f9aa3fa3e22",
    "url": "/static/css/2.c8a97453.chunk.css"
  },
  {
    "revision": "4a1e879f468fb53930ae72d54362c6c0",
    "url": "/index.html"
  }
];