self.__precacheManifest = [
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "88959145c730d1a150bc",
    "url": "/static/js/main.ffcf041f.chunk.js"
  },
  {
    "revision": "1adcac4a41a7a6eca6eb",
    "url": "/static/js/2.bbfe1cbe.chunk.js"
  },
  {
    "revision": "88959145c730d1a150bc",
    "url": "/static/css/main.a8d432f4.chunk.css"
  },
  {
    "revision": "1adcac4a41a7a6eca6eb",
    "url": "/static/css/2.be9ec85e.chunk.css"
  },
  {
    "revision": "e141a5a899510edcfa79a42546509d82",
    "url": "/index.html"
  }
];